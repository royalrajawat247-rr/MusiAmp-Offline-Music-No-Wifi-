package com.surtaal.music

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

sealed interface Overlay {
    data object None : Overlay
    data object NowPlaying : Overlay
    data object Equalizer : Overlay
    data object Settings : Overlay
    data object Pro : Overlay
    data class Tag(val song: Song) : Overlay
    data class Songs(val title: String, val songs: List<Song>, val playlistId: String? = null) : Overlay
}

@Composable
fun SurTaalApp(vm: PlayerViewModel, activity: Activity) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var overlay by remember { mutableStateOf<Overlay>(Overlay.None) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var addTo by remember { mutableStateOf<Song?>(null) }
    var newPl by remember { mutableStateOf(false) }
    var pendingSong by remember { mutableStateOf<Song?>(null) }
    var showTimer by remember { mutableStateOf(false) }

    BackHandler(enabled = overlay != Overlay.None) { overlay = Overlay.None }
    BackHandler(enabled = overlay == Overlay.None && searching) {
        searching = false
        query = ""
    }

    val filtered = remember(vm.songs, query) {
        if (query.isBlank()) vm.songs
        else vm.songs.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }

    val onTag: (Song) -> Unit = { overlay = Overlay.Tag(it) }
    val onAddPl: (Song) -> Unit = { addTo = it }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopBar(
                    vm = vm,
                    searching = searching,
                    query = query,
                    onQuery = { query = it },
                    onSearch = { searching = true; tab = 0 },
                    onCloseSearch = { searching = false; query = "" },
                    onSettings = { overlay = Overlay.Settings },
                    onPro = { overlay = Overlay.Pro }
                )
            },
            bottomBar = {
                Column {
                    if (!vm.isPro) BannerAd()
                    MiniPlayer(vm) { overlay = Overlay.NowPlaying }
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                        val items = listOf(
                            "गाने" to Icons.Rounded.MusicNote,
                            "एल्बम" to Icons.Rounded.Album,
                            "कलाकार" to Icons.Rounded.Person,
                            "फ़ोल्डर" to Icons.Rounded.Folder,
                            "प्लेलिस्ट" to Icons.Rounded.QueueMusic
                        )
                        items.forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, maxLines = 1) }
                            )
                        }
                    }
                }
            }
        ) { pad ->
            Box(
                Modifier
                    .padding(pad)
                    .fillMaxSize()
            ) {
                when {
                    vm.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }

                    vm.songs.isEmpty() && tab != 4 -> Column(
                        Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        EmptyState(
                            "कोई गाना नहीं मिला",
                            "अपने फ़ोन में MP3 या दूसरे गाने डालें, फिर नीचे का बटन दबाएँ.",
                            Modifier.weight(1f, fill = false)
                        )
                        Button(onClick = { vm.reload() }, shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Rounded.Refresh, null)
                            Spacer(Modifier.width(8.dp))
                            Text("दोबारा खोजें")
                        }
                    }

                    tab == 0 -> SongListColumn(vm, filtered, onTag, onAddPl)

                    tab == 1 -> AlbumsTab(vm.songs) { name, list -> overlay = Overlay.Songs(name, list) }

                    tab == 2 -> ArtistsTab(vm.songs) { name, list -> overlay = Overlay.Songs(name, list) }

                    tab == 3 -> FoldersTab(vm.songs) { name, list -> overlay = Overlay.Songs(name, list) }

                    else -> PlaylistsTab(
                        vm = vm,
                        onOpenFav = { overlay = Overlay.Songs("पसंदीदा", vm.songs.filter { vm.favorites.contains(it.id) }) },
                        onOpen = { p -> overlay = Overlay.Songs(p.name, vm.songsOf(p.songIds), p.id) },
                        onNew = { pendingSong = null; newPl = true }
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = overlay == Overlay.NowPlaying,
            enter = slideInVertically { it },
            exit = slideOutVertically { it }
        ) {
            NowPlayingScreen(
                vm = vm,
                onClose = { overlay = Overlay.None },
                onEq = { overlay = Overlay.Equalizer },
                onTimer = { showTimer = true },
                onTag = { overlay = Overlay.Tag(it) }
            )
        }

        when (val o = overlay) {
            Overlay.Equalizer -> EqualizerScreen(vm) { overlay = Overlay.None }
            Overlay.Settings -> SettingsScreen(
                vm = vm,
                onBack = { overlay = Overlay.None },
                onPro = { overlay = Overlay.Pro }
            )
            Overlay.Pro -> ProScreen(vm, activity) { overlay = Overlay.None }
            is Overlay.Tag -> TagScreen(vm, o.song) { overlay = Overlay.None }
            is Overlay.Songs -> Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column {
                    ScreenHeader(o.title) { overlay = Overlay.None }
                    if (o.songs.isEmpty()) {
                        EmptyState("यहाँ अभी कोई गाना नहीं है", "गाने के आगे ⋮ दबाकर उसे जोड़ें.")
                    } else {
                        SongListColumn(vm, o.songs, onTag, onAddPl, o.playlistId)
                    }
                }
            }
            else -> {}
        }
    }

    // ---------- डायलॉग ----------
    addTo?.let { s ->
        AlertDialog(
            onDismissRequest = { addTo = null },
            title = { Text("प्लेलिस्ट में जोड़ें") },
            text = {
                Column {
                    if (vm.playlists.isEmpty()) Text("अभी कोई प्लेलिस्ट नहीं है. नीचे से नई बनाएँ.")
                    vm.playlists.forEach { p ->
                        TextButton(onClick = { vm.addToPlaylist(p.id, s.id); addTo = null }) {
                            Text(p.name)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { pendingSong = s; addTo = null; newPl = true }) {
                    Text("+ नई प्लेलिस्ट")
                }
            },
            dismissButton = { TextButton(onClick = { addTo = null }) { Text("रद्द करें") } }
        )
    }

    if (newPl) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newPl = false },
            title = { Text("नई प्लेलिस्ट") },
            text = {
                TextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    placeholder = { Text("प्लेलिस्ट का नाम") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val id = vm.createPlaylist(name)
                    val ps = pendingSong
                    if (id != null && ps != null) vm.addToPlaylist(id, ps.id)
                    pendingSong = null
                    newPl = false
                }) { Text("बनाएँ") }
            },
            dismissButton = { TextButton(onClick = { newPl = false }) { Text("रद्द करें") } }
        )
    }

    if (showTimer) {
        AlertDialog(
            onDismissRequest = { showTimer = false },
            title = { Text("सोने का टाइमर") },
            text = {
                Column {
                    listOf(15, 30, 45, 60, 90).forEach { m ->
                        TextButton(onClick = { vm.setSleep(m); showTimer = false }) {
                            Text("$m मिनट बाद गाना बंद करें")
                        }
                    }
                    if (vm.sleepEndsAt > 0) {
                        TextButton(onClick = { vm.setSleep(0); showTimer = false }) {
                            Text("टाइमर बंद करें")
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTimer = false }) { Text("ठीक है") } }
        )
    }
}

@Composable
private fun TopBar(
    vm: PlayerViewModel,
    searching: Boolean,
    query: String,
    onQuery: (String) -> Unit,
    onSearch: () -> Unit,
    onCloseSearch: () -> Unit,
    onSettings: () -> Unit,
    onPro: () -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .heightIn(min = 56.dp)
            .padding(start = 20.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (searching) {
            val focus = remember { FocusRequester() }
            LaunchedEffect(Unit) { focus.requestFocus() }
            TextField(
                value = query,
                onValueChange = onQuery,
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus),
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                placeholder = { Text("गाना, कलाकार या एल्बम खोजें") },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = scheme.surfaceVariant,
                    unfocusedContainerColor = scheme.surfaceVariant,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                )
            )
            IconButton(onClick = onCloseSearch) { Icon(Icons.Rounded.Close, "बंद करें") }
        } else {
            Text(
                "सुरताल",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = scheme.primary,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onSearch) { Icon(Icons.Rounded.Search, "खोजें") }
            if (!vm.isPro) {
                IconButton(onClick = onPro) {
                    Icon(Icons.Rounded.Star, "प्रो", tint = Color(0xFFFFB300))
                }
            }
            IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, "सेटिंग्स") }
        }
    }
}

@Composable
private fun MiniPlayer(vm: PlayerViewModel, onOpen: () -> Unit) {
    val song = vm.current ?: return
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .background(scheme.primaryContainer)
            .clickable(onClick = onOpen)
            .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(song, Modifier.size(46.dp), radius = 10.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.SemiBold,
                color = scheme.onSurface
            )
            Text(
                song.artist,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant
            )
        }
        IconButton(onClick = { vm.togglePlay() }) {
            Icon(
                if (vm.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = "चलाएँ या रोकें",
                modifier = Modifier.size(30.dp)
            )
        }
        IconButton(onClick = { vm.next() }) {
            Icon(Icons.Rounded.SkipNext, contentDescription = "अगला")
        }
    }
}

@Composable
fun SongListColumn(
    vm: PlayerViewModel,
    songs: List<Song>,
    onTag: (Song) -> Unit,
    onAddPl: (Song) -> Unit,
    playlistId: String? = null
) {
    val curId = vm.current?.id
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { vm.play(songs, 0) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.width(6.dp))
                    Text("सभी चलाएँ (${songs.size})", maxLines = 1)
                }
                FilledTonalButton(
                    onClick = { vm.playShuffled(songs) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.Shuffle, null)
                    Spacer(Modifier.width(6.dp))
                    Text("शफ़ल")
                }
            }
        }
        itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
            SongRow(vm, s, s.id == curId, { vm.play(songs, i) }, onTag, onAddPl, playlistId)
        }
    }
}

@Composable
private fun AlbumsTab(songs: List<Song>, onOpen: (String, List<Song>) -> Unit) {
    val groups = remember(songs) {
        songs.groupBy { it.albumId to it.album }.entries.sortedBy { it.key.second.lowercase() }
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(groups, key = { "${it.key.first}-${it.key.second}" }) { g ->
            Column(Modifier.clickable { onOpen(g.key.second, g.value) }) {
                Art(g.value.first(), Modifier.fillMaxWidth().aspectRatio(1f), px = 400, radius = 18.dp)
                Spacer(Modifier.padding(top = 8.dp))
                Text(
                    g.key.second,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "${g.value.first().artist} • ${g.value.size} गाने",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun GroupRow(title: String, count: Int, onClick: () -> Unit, leading: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        leading()
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(
                "$count गाने",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ArtistsTab(songs: List<Song>, onOpen: (String, List<Song>) -> Unit) {
    val groups = remember(songs) {
        songs.groupBy { it.artist }.entries.sortedBy { it.key.lowercase() }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        items(groups, key = { it.key }) { g ->
            GroupRow(g.key, g.value.size, { onOpen(g.key, g.value) }) {
                Box(
                    Modifier
                        .size(52.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        g.key.take(1),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun FoldersTab(songs: List<Song>, onOpen: (String, List<Song>) -> Unit) {
    val groups = remember(songs) {
        songs.groupBy { it.folder }.entries.sortedBy { it.key.lowercase() }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        items(groups, key = { it.key }) { g ->
            GroupRow(g.key, g.value.size, { onOpen(g.key, g.value) }) {
                Box(
                    Modifier
                        .size(52.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun PlaylistsTab(
    vm: PlayerViewModel,
    onOpenFav: () -> Unit,
    onOpen: (Playlist) -> Unit,
    onNew: () -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(Modifier.padding(16.dp)) {
                Button(onClick = onNew, shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Rounded.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text("नई प्लेलिस्ट बनाएँ")
                }
            }
        }
        item {
            GroupRow("पसंदीदा", vm.favorites.size, onOpenFav) {
                Box(
                    Modifier
                        .size(52.dp)
                        .background(scheme.primaryContainer, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Favorite, null, tint = scheme.primary)
                }
            }
        }
        items(vm.playlists, key = { it.id }) { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    GroupRow(p.name, p.songIds.size, { onOpen(p) }) {
                        Box(
                            Modifier
                                .size(52.dp)
                                .background(scheme.primaryContainer, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.QueueMusic, null, tint = scheme.primary)
                        }
                    }
                }
                IconButton(onClick = { vm.deletePlaylist(p.id) }) {
                    Icon(Icons.Rounded.Delete, contentDescription = "प्लेलिस्ट हटाएँ")
                }
            }
        }
    }
}
