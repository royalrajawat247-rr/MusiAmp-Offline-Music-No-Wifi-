package com.surtaal.music

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer

/** इक्वलाइज़र, बेस और आवाज़ बढ़ाने वाला (वॉल्यूम बूस्टर). */
object AudioFx {
    private var eq: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loud: LoudnessEnhancer? = null

    var supported = false
        private set
    var bandCount = 0
        private set
    var minLevel = -1500
        private set
    var maxLevel = 1500
        private set
    var freqs: List<Int> = emptyList()
        private set

    val presets: List<Pair<String, FloatArray>> = listOf(
        "सामान्य" to floatArrayOf(0f, 0f, 0f, 0f, 0f),
        "बेस" to floatArrayOf(0.8f, 0.5f, 0f, 0f, 0f),
        "ट्रेबल" to floatArrayOf(0f, 0f, 0f, 0.5f, 0.8f),
        "आवाज़" to floatArrayOf(-0.3f, 0.2f, 0.6f, 0.4f, -0.1f),
        "रॉक" to floatArrayOf(0.6f, 0.3f, -0.3f, 0.3f, 0.6f),
        "पॉप" to floatArrayOf(-0.2f, 0.3f, 0.5f, 0.3f, -0.2f)
    )

    fun attach(sessionId: Int, s: Store) {
        release()
        if (sessionId == 0) return
        try {
            val e = Equalizer(0, sessionId)
            bandCount = e.numberOfBands.toInt()
            minLevel = e.bandLevelRange[0].toInt()
            maxLevel = e.bandLevelRange[1].toInt()
            freqs = (0 until bandCount).map { e.getCenterFreq(it.toShort()) / 1000 }
            val saved = s.eqLevels()
            for (i in 0 until bandCount) {
                val lv = (saved.getOrNull(i) ?: 0).coerceIn(minLevel, maxLevel)
                e.setBandLevel(i.toShort(), lv.toShort())
            }
            e.enabled = s.eqOn
            eq = e
            supported = true
        } catch (_: Throwable) {
            supported = false
        }
        try {
            val b = BassBoost(0, sessionId)
            if (b.strengthSupported) b.setStrength(s.bass.coerceIn(0, 1000).toShort())
            b.enabled = s.bass > 0
            bassBoost = b
        } catch (_: Throwable) {
        }
        try {
            val l = LoudnessEnhancer(sessionId)
            l.setTargetGain(gainFor(s.boost))
            l.enabled = s.boost > 100
            loud = l
        } catch (_: Throwable) {
        }
    }

    fun release() {
        try { eq?.release() } catch (_: Throwable) {}
        try { bassBoost?.release() } catch (_: Throwable) {}
        try { loud?.release() } catch (_: Throwable) {}
        eq = null
        bassBoost = null
        loud = null
    }

    fun levelsFor(s: Store): List<Int> {
        val saved = s.eqLevels()
        return (0 until bandCount).map { saved.getOrNull(it) ?: 0 }
    }

    fun setEnabled(on: Boolean) {
        try { eq?.enabled = on } catch (_: Throwable) {}
    }

    fun setBand(i: Int, level: Int) {
        try { eq?.setBandLevel(i.toShort(), level.coerceIn(minLevel, maxLevel).toShort()) } catch (_: Throwable) {}
    }

    fun setBass(strength: Int) {
        try {
            val b = bassBoost ?: return
            if (b.strengthSupported) b.setStrength(strength.coerceIn(0, 1000).toShort())
            b.enabled = strength > 0
        } catch (_: Throwable) {
        }
    }

    fun setBoost(percent: Int) {
        try {
            val l = loud ?: return
            l.setTargetGain(gainFor(percent))
            l.enabled = percent > 100
        } catch (_: Throwable) {
        }
    }

    private fun gainFor(percent: Int): Int = ((percent - 100).coerceIn(0, 100)) * 8

    fun presetLevels(p: FloatArray): List<Int> = (0 until bandCount).map { i ->
        val pos = if (bandCount <= 1) 0f else i * (p.size - 1).toFloat() / (bandCount - 1)
        val lo = pos.toInt()
        val hi = minOf(lo + 1, p.size - 1)
        val v = p[lo] + (p[hi] - p[lo]) * (pos - lo)
        (v * maxLevel).toInt()
    }
}
