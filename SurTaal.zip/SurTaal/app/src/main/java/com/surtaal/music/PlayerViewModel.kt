package com.surtaal.music

import android.app.Activity
import android.app.Application
import android.content.ComponentName
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    val store = Store(app)
    val player: ExoPlayer = PlayerHolder.get(app)
    val billing = Billing(app) { setPro(it) }

    private var raw: List<Song> = emptyList()
    private var byId: Map<Long, Song> = emptyMap()

    var songs by mutableStateOf<List<Song>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var current by mutableStateOf<Song?>(null)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_OFF)
        private set

    var playlists by mutableStateOf(store.playlists())
        private set
    var favorites by mutableStateOf(store.favorites())
        private set
    var tags by mutableStateOf(store.tags())
        private set

    var isPro by mutableStateOf(store.isPro)
        private set
    var accent by mutableIntStateOf(store.accent)
        private set
    var themeMode by mutableIntStateOf(store.themeMode)
        private set

    var eqOn by mutableStateOf(store.eqOn)
        private set
    var eqLevels by mutableStateOf<List<Int>>(emptyList())
        private set
    var bass by mutableIntStateOf(store.bass)
        private set
    var boost by mutableIntStateOf(store.boost)
        private set

    var sleepEndsAt by mutableLongStateOf(0L)
        private set
    private var sleepJob: Job? = null

    init {
        AudioFx.attach(player.audioSessionId, store)
        eqLevels = AudioFx.levelsFor(store)

        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                current = byId[mediaItem?.mediaId?.toLongOrNull() ?: -1L]
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onShuffleModeEnabledChanged(enabled: Boolean) {
                shuffle = enabled
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                repeat = repeatMode
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioFx.attach(audioSessionId, store)
                eqLevels = AudioFx.levelsFor(store)
            }
        })
        isPlaying = player.isPlaying
        shuffle = player.shuffleModeEnabled
        repeat = player.repeatMode

        // सेवा से जुड़ना ताकि नोटिफ़िकेशन और लॉक-स्क्रीन कंट्रोल चलें
        try {
            val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
            MediaController.Builder(app, token).buildAsync()
        } catch (_: Throwable) {
        }

        if (!isPro) {
            try { MobileAds.initialize(app) } catch (_: Throwable) {}
        }
        billing.start()
    }

    // ---------- गाने खोजना ----------
    fun reload() {
        viewModelScope.launch {
            loading = true
            raw = withContext(Dispatchers.IO) { MusicRepo.load(getApplication()) }
            applyTags()
            loading = false
        }
    }

    private fun applyTags() {
        songs = raw.map { s ->
            val t = tags[s.id]
            if (t == null) s else s.copy(
                title = t.title.ifBlank { s.title },
                artist = t.artist.ifBlank { s.artist },
                album = t.album.ifBlank { s.album }
            )
        }
        byId = songs.associateBy { it.id }
        current = byId[player.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L]
    }

    fun songsOf(ids: List<Long>): List<Song> = ids.mapNotNull { byId[it] }

    private fun item(s: Song): MediaItem = MediaItem.Builder()
        .setMediaId(s.id.toString())
        .setUri(s.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(s.title)
                .setArtist(s.artist)
                .setAlbumTitle(s.album)
                .build()
        )
        .build()

    // ---------- चलाना ----------
    fun play(list: List<Song>, index: Int) {
        if (list.isEmpty()) return
        player.setMediaItems(list.map { item(it) }, index.coerceIn(0, list.size - 1), 0L)
        player.prepare()
        player.play()
        current = list[index.coerceIn(0, list.size - 1)]
    }

    fun playShuffled(list: List<Song>) {
        if (list.isEmpty()) return
        player.shuffleModeEnabled = true
        play(list, list.indices.random())
    }

    fun playNext(song: Song) {
        if (player.mediaItemCount == 0) {
            play(listOf(song), 0)
        } else {
            player.addMediaItem(player.currentMediaItemIndex + 1, item(song))
        }
    }

    fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
    }

    fun next() = player.seekToNext()
    fun previous() = player.seekToPrevious()

    fun toggleShuffle() {
        player.shuffleModeEnabled = !player.shuffleModeEnabled
    }

    fun cycleRepeat() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    // ---------- सोने का टाइमर ----------
    fun setSleep(minutes: Int) {
        sleepJob?.cancel()
        if (minutes <= 0) {
            sleepEndsAt = 0L
            return
        }
        sleepEndsAt = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = viewModelScope.launch {
            delay(minutes * 60_000L)
            player.pause()
            sleepEndsAt = 0L
        }
    }

    // ---------- पसंदीदा और प्लेलिस्ट ----------
    fun toggleFavorite(id: Long) {
        favorites = if (favorites.contains(id)) favorites - id else favorites + id
        store.saveFavorites(favorites)
    }

    fun createPlaylist(name: String): String? {
        val n = name.trim()
        if (n.isEmpty()) return null
        val id = System.currentTimeMillis().toString()
        playlists = playlists + Playlist(id, n, emptyList())
        store.savePlaylists(playlists)
        return id
    }

    fun addToPlaylist(playlistId: String, songId: Long) {
        playlists = playlists.map {
            if (it.id == playlistId && !it.songIds.contains(songId)) it.copy(songIds = it.songIds + songId) else it
        }
        store.savePlaylists(playlists)
    }

    fun removeFromPlaylist(playlistId: String, songId: Long) {
        playlists = playlists.map {
            if (it.id == playlistId) it.copy(songIds = it.songIds - songId) else it
        }
        store.savePlaylists(playlists)
    }

    fun deletePlaylist(playlistId: String) {
        playlists = playlists.filter { it.id != playlistId }
        store.savePlaylists(playlists)
    }

    // ---------- गाने की जानकारी बदलना (अक्षर-सीमा नहीं, प्लेलिस्ट कभी नहीं हटती) ----------
    fun saveTag(id: Long, t: TagEdit) {
        tags = tags + (id to t)
        store.saveTags(tags)
        applyTags()
        val s = byId[id] ?: return
        for (i in 0 until player.mediaItemCount) {
            if (i != player.currentMediaItemIndex && player.getMediaItemAt(i).mediaId == id.toString()) {
                player.replaceMediaItem(i, item(s))
            }
        }
    }

    fun resetTag(id: Long) {
        tags = tags - id
        store.saveTags(tags)
        applyTags()
    }

    // ---------- इक्वलाइज़र ----------
    fun setEqOn(on: Boolean) {
        eqOn = on
        store.eqOn = on
        AudioFx.setEnabled(on)
    }

    fun setBand(i: Int, level: Int) {
        eqLevels = eqLevels.toMutableList().also { if (i in it.indices) it[i] = level }
        AudioFx.setBand(i, level)
        store.saveEqLevels(eqLevels)
        if (!eqOn) setEqOn(true)
    }

    fun applyPreset(index: Int) {
        val lv = AudioFx.presetLevels(AudioFx.presets[index].second)
        lv.forEachIndexed { i, v -> AudioFx.setBand(i, v) }
        eqLevels = lv
        store.saveEqLevels(lv)
        setEqOn(true)
    }

    fun setBass(v: Int) {
        bass = v
        store.bass = v
        AudioFx.setBass(v)
    }

    fun setBoost(v: Int) {
        boost = v
        store.boost = v
        AudioFx.setBoost(v)
    }

    // ---------- रूप-रंग ----------
    fun setTheme(m: Int) {
        themeMode = m
        store.themeMode = m
    }

    fun setAccent(i: Int) {
        accent = i
        store.accent = i
    }

    // ---------- प्रो ----------
    private fun setPro(v: Boolean) {
        isPro = v
        store.isPro = v
    }

    fun buyPro(activity: Activity) = billing.buy(activity)
    fun restorePro() = billing.restore()
}
