package com.surtaal.music

import android.app.Activity
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams

/**
 * एक बार का "सुरताल प्रो" (₹49.99). Play Console में इसी ID से
 * "One-time product" बनाइए: pro_lifetime
 */
class Billing(ctx: Context, private val onPro: (Boolean) -> Unit) : PurchasesUpdatedListener {

    companion object {
        const val PRODUCT = "pro_lifetime"
    }

    var price by mutableStateOf("₹49.99")
    var message by mutableStateOf("")

    private var details: ProductDetails? = null

    private val client: BillingClient = BillingClient.newBuilder(ctx.applicationContext)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    fun start() {
        if (client.isReady) return
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    loadDetails()
                    restore()
                }
            }

            override fun onBillingServiceDisconnected() {}
        })
    }

    private fun loadDetails() {
        val product = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(PRODUCT)
            .setProductType(BillingClient.ProductType.INAPP)
            .build()
        val params = QueryProductDetailsParams.newBuilder().setProductList(listOf(product)).build()
        client.queryProductDetailsAsync(params) { result, list ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                details = list.firstOrNull()
                details?.oneTimePurchaseOfferDetails?.formattedPrice?.let { price = it }
            }
        }
    }

    fun restore() {
        if (!client.isReady) {
            start()
            return
        }
        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP)
            .build()
        client.queryPurchasesAsync(params) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) handle(purchases)
        }
    }

    fun buy(activity: Activity) {
        val d = details
        if (d == null) {
            message = "अभी Play Store से जुड़ नहीं पा रहे. इंटरनेट जाँचकर दोबारा कोशिश करें."
            start()
            return
        }
        val pd = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).build()
        val flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(pd)).build()
        client.launchBillingFlow(activity, flow)
    }

    private fun handle(purchases: List<Purchase>) {
        for (p in purchases) {
            if (p.products.contains(PRODUCT) && p.purchaseState == Purchase.PurchaseState.PURCHASED) {
                if (!p.isAcknowledged) {
                    val ack = AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(p.purchaseToken)
                        .build()
                    client.acknowledgePurchase(ack) { }
                }
                onPro(true)
            }
        }
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            handle(purchases)
        }
    }
}
