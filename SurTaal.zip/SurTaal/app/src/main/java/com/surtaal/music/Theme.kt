package com.surtaal.music

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accents = listOf(
    Color(0xFFFF4D6D),
    Color(0xFF7C4DFF),
    Color(0xFF00BFA5),
    Color(0xFFFFB300),
    Color(0xFF29B6F6),
    Color(0xFFFF7043)
)
val AccentNames = listOf("गुलाबी", "जामुनी", "हरा", "सुनहरा", "आसमानी", "नारंगी")
const val FreeAccents = 2

@Composable
fun SurTaalTheme(mode: Int, accentIndex: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val accent = Accents[accentIndex.coerceIn(0, Accents.lastIndex)]
    val scheme = if (dark) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color.White,
            primaryContainer = accent.copy(alpha = 0.22f),
            onPrimaryContainer = Color.White,
            background = Color(0xFF0E0E12),
            onBackground = Color(0xFFF2F2F7),
            surface = Color(0xFF0E0E12),
            onSurface = Color(0xFFF2F2F7),
            surfaceVariant = Color(0xFF1C1C24),
            onSurfaceVariant = Color(0xFFA6A6B8),
            outline = Color(0xFF3A3A48)
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = Color.White,
            primaryContainer = accent.copy(alpha = 0.16f),
            onPrimaryContainer = Color(0xFF1A1A22),
            background = Color(0xFFFAFAFD),
            onBackground = Color(0xFF16161D),
            surface = Color(0xFFFAFAFD),
            onSurface = Color(0xFF16161D),
            surfaceVariant = Color(0xFFEDEDF4),
            onSurfaceVariant = Color(0xFF5E5E70),
            outline = Color(0xFFCFCFDB)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
