package com.surtaal.music

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun freqLabel(hz: Int): String =
    if (hz >= 1000) "%.1f kHz".format(hz / 1000f) else "$hz Hz"

// ===================== इक्वलाइज़र =====================
@Composable
fun EqualizerScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Surface(Modifier.fillMaxSize(), color = scheme.background) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("इक्वलाइज़र और आवाज़", onBack)
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .navigationBarsPadding()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "इक्वलाइज़र चालू",
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Switch(checked = vm.eqOn, onCheckedChange = { vm.setEqOn(it) })
                }
                if (!AudioFx.supported) {
                    Text(
                        "इस फ़ोन पर इक्वलाइज़र अभी उपलब्ध नहीं है. कोई गाना चलाने के बाद दोबारा खोलें.",
                        color = scheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AudioFx.presets.forEachIndexed { i, p ->
                        FilterChip(
                            selected = false,
                            onClick = { vm.applyPreset(i) },
                            label = { Text(p.first) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                vm.eqLevels.forEachIndexed { i, level ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            freqLabel(AudioFx.freqs.getOrElse(i) { 0 }),
                            Modifier.width(72.dp),
                            style = MaterialTheme.typography.labelMedium,
                            color = scheme.onSurfaceVariant
                        )
                        Slider(
                            value = level.toFloat(),
                            onValueChange = { vm.setBand(i, it.toInt()) },
                            valueRange = AudioFx.minLevel.toFloat()..AudioFx.maxLevel.toFloat(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))
                Text("बेस बूस्ट: ${vm.bass / 10}%", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = vm.bass.toFloat(),
                    onValueChange = { vm.setBass(it.toInt()) },
                    valueRange = 0f..1000f
                )

                Spacer(Modifier.height(8.dp))
                Text("आवाज़ बढ़ाएँ (वॉल्यूम बूस्टर): ${vm.boost}%", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = vm.boost.toFloat(),
                    onValueChange = { vm.setBoost(it.toInt()) },
                    valueRange = 100f..200f
                )
                Text(
                    "ध्यान रखें: बहुत तेज़ आवाज़ से कान और स्पीकर को नुक़सान हो सकता है.",
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.onSurfaceVariant
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

// ===================== सेटिंग्स =====================
@Composable
fun SettingsScreen(vm: PlayerViewModel, onBack: () -> Unit, onPro: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Surface(Modifier.fillMaxSize(), color = scheme.background) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("सेटिंग्स", onBack)
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .navigationBarsPadding()
            ) {
                Card(
                    onClick = onPro,
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = scheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Star, null, tint = Color(0xFFFFB300), modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(
                                if (vm.isPro) "सुरताल प्रो चालू है ✓" else "सुरताल प्रो लें",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                if (vm.isPro) "आपका धन्यवाद! कोई विज्ञापन नहीं."
                                else "सिर्फ़ ${vm.billing.price}, एक बार. सारे विज्ञापन बंद.",
                                style = MaterialTheme.typography.bodySmall,
                                color = scheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(Modifier.height(24.dp))
                Text("रूप", style = MaterialTheme.typography.titleSmall, color = scheme.primary)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("सिस्टम जैसा", "उजला", "अंधेरा").forEachIndexed { i, label ->
                        FilterChip(
                            selected = vm.themeMode == i,
                            onClick = { vm.setTheme(i) },
                            label = { Text(label) }
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))
                Text("रंग", style = MaterialTheme.typography.titleSmall, color = scheme.primary)
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Accents.forEachIndexed { i, c ->
                        val locked = i >= FreeAccents && !vm.isPro
                        Box(
                            Modifier
                                .size(46.dp)
                                .background(c, CircleShape)
                                .border(
                                    if (vm.accent == i) 3.dp else 0.dp,
                                    scheme.onBackground,
                                    CircleShape
                                )
                                .clickable { if (locked) onPro() else vm.setAccent(i) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (locked) Icon(Icons.Rounded.Lock, "प्रो चाहिए", tint = Color.White)
                            else if (vm.accent == i) Icon(Icons.Rounded.Check, AccentNames[i], tint = Color.White)
                        }
                    }
                }
                if (!vm.isPro) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "बाकी रंग प्रो में खुलते हैं.",
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant
                    )
                }

                Spacer(Modifier.height(24.dp))
                Text("गाने", style = MaterialTheme.typography.titleSmall, color = scheme.primary)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.reload() }, shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Rounded.Refresh, null)
                    Spacer(Modifier.width(8.dp))
                    Text("गाने दोबारा खोजें")
                }

                Spacer(Modifier.height(24.dp))
                Text("हमारा वादा", style = MaterialTheme.typography.titleSmall, color = scheme.primary)
                Spacer(Modifier.height(6.dp))
                Text(
                    "• गाने के बीच या गाना बदलते समय कभी विज्ञापन नहीं आएगा.\n" +
                        "• मुफ़्त संस्करण में सिर्फ़ नीचे एक छोटी पट्टी दिखती है.\n" +
                        "• आपके गाने, प्लेलिस्ट और जानकारी सिर्फ़ आपके फ़ोन में रहती है.",
                    color = scheme.onSurfaceVariant
                )

                Spacer(Modifier.height(24.dp))
                Text(
                    "सुरताल • संस्करण 1.0.0 • भारत में बना",
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

// ===================== प्रो =====================
@Composable
fun ProScreen(vm: PlayerViewModel, activity: Activity, onBack: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Surface(Modifier.fillMaxSize(), color = scheme.background) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("सुरताल प्रो", onBack)
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(listOf(Color(0xFFFF4D6D), Color(0xFF7C4DFF))),
                            RoundedCornerShape(28.dp)
                        )
                        .padding(28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.Star, null, tint = Color(0xFFFFE082), modifier = Modifier.size(52.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("सिर्फ़", color = Color.White.copy(alpha = 0.85f))
                        Text(
                            vm.billing.price,
                            color = Color.White,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            "एक बार का भुगतान • हमेशा के लिए",
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }

                Spacer(Modifier.height(24.dp))
                listOf(
                    "सारे विज्ञापन हमेशा के लिए बंद",
                    "सभी 6 रंग-थीम खुल जाएँगी",
                    "आगे आने वाले नए फ़ीचर भी मुफ़्त",
                    "एक छोटे भारतीय ऐप का सहारा"
                ).forEach {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Check, null, tint = scheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Text(it, style = MaterialTheme.typography.bodyLarge)
                    }
                }

                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = { vm.buyPro(activity) },
                    enabled = !vm.isPro,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        if (vm.isPro) "आप प्रो हैं ✓" else "${vm.billing.price} में प्रो लें",
                        fontWeight = FontWeight.Bold
                    )
                }
                TextButton(onClick = { vm.restorePro() }) { Text("पहले की खरीदारी वापस लाएँ") }
                if (vm.billing.message.isNotBlank()) {
                    Text(
                        vm.billing.message,
                        color = scheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

// ===================== गाने की जानकारी बदलना =====================
@Composable
fun TagScreen(vm: PlayerViewModel, song: Song, onBack: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    var title by remember { mutableStateOf(song.title) }
    var artist by remember { mutableStateOf(song.artist) }
    var album by remember { mutableStateOf(song.album) }
    var lyrics by remember { mutableStateOf(vm.tags[song.id]?.lyrics.orEmpty()) }

    Surface(Modifier.fillMaxSize(), color = scheme.background) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("गाने की जानकारी", onBack)
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .navigationBarsPadding()
            ) {
                Text(
                    "यहाँ जितनी चाहें उतनी लंबी जानकारी लिख सकते हैं. बदलने पर आपका गाना प्लेलिस्ट से कभी नहीं हटेगा.",
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.onSurfaceVariant
                )
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text("गाने का नाम") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = artist, onValueChange = { artist = it },
                    label = { Text("कलाकार") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = album, onValueChange = { album = it },
                    label = { Text("एल्बम") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = lyrics, onValueChange = { lyrics = it },
                    label = { Text("गीत के बोल") },
                    minLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            vm.saveTag(song.id, TagEdit(title.trim(), artist.trim(), album.trim(), lyrics))
                            onBack()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("सहेजें") }
                    OutlinedButton(
                        onClick = { vm.resetTag(song.id); onBack() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("पहले जैसा करें") }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
