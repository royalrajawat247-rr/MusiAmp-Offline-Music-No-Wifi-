package com.surtaal.music

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val folder: String,
    val uri: Uri
)

data class Playlist(
    val id: String,
    val name: String,
    val songIds: List<Long>
)

/** गाने की अपनी जानकारी (कोई अक्षर-सीमा नहीं). ऐप के अंदर सुरक्षित रहती है. */
data class TagEdit(
    val title: String,
    val artist: String,
    val album: String,
    val lyrics: String
)
