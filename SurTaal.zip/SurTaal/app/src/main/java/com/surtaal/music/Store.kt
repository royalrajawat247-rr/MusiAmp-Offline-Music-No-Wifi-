package com.surtaal.music

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** सारी सेटिंग्स, प्लेलिस्ट और गाने की जानकारी फ़ोन में ही सहेजता है. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("surtaal", Context.MODE_PRIVATE)

    var themeMode: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    var accent: Int
        get() = sp.getInt("accent", 0)
        set(v) { sp.edit().putInt("accent", v).apply() }

    var isPro: Boolean
        get() = sp.getBoolean("pro", false)
        set(v) { sp.edit().putBoolean("pro", v).apply() }

    var eqOn: Boolean
        get() = sp.getBoolean("eqOn", false)
        set(v) { sp.edit().putBoolean("eqOn", v).apply() }

    var bass: Int
        get() = sp.getInt("bass", 0)
        set(v) { sp.edit().putInt("bass", v).apply() }

    /** आवाज़ बढ़ाना: 100 से 200 (प्रतिशत) */
    var boost: Int
        get() = sp.getInt("boost", 100)
        set(v) { sp.edit().putInt("boost", v).apply() }

    fun eqLevels(): List<Int> =
        sp.getString("eqLevels", "")!!.split(",").mapNotNull { it.trim().toIntOrNull() }

    fun saveEqLevels(l: List<Int>) {
        sp.edit().putString("eqLevels", l.joinToString(",")).apply()
    }

    fun favorites(): Set<Long> =
        sp.getString("fav", "")!!.split(",").mapNotNull { it.trim().toLongOrNull() }.toSet()

    fun saveFavorites(s: Set<Long>) {
        sp.edit().putString("fav", s.joinToString(",")).apply()
    }

    fun playlists(): List<Playlist> {
        val out = mutableListOf<Playlist>()
        try {
            val arr = JSONArray(sp.getString("playlists", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ids = o.getJSONArray("songs")
                out.add(
                    Playlist(
                        o.getString("id"),
                        o.getString("name"),
                        (0 until ids.length()).map { ids.getLong(it) }
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun savePlaylists(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            val ids = JSONArray()
            p.songIds.forEach { ids.put(it) }
            o.put("songs", ids)
            arr.put(o)
        }
        sp.edit().putString("playlists", arr.toString()).apply()
    }

    fun tags(): Map<Long, TagEdit> {
        val out = mutableMapOf<Long, TagEdit>()
        try {
            val root = JSONObject(sp.getString("tags", "{}"))
            root.keys().forEach { k ->
                val o = root.getJSONObject(k)
                out[k.toLong()] = TagEdit(
                    o.optString("t"), o.optString("a"), o.optString("al"), o.optString("l")
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun saveTags(m: Map<Long, TagEdit>) {
        val root = JSONObject()
        m.forEach { (id, t) ->
            val o = JSONObject()
            o.put("t", t.title)
            o.put("a", t.artist)
            o.put("al", t.album)
            o.put("l", t.lyrics)
            root.put(id.toString(), o)
        }
        sp.edit().putString("tags", root.toString()).apply()
    }
}
