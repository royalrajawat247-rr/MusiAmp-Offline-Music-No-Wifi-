package com.surtaal.music

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object MusicRepo {

    @Suppress("DEPRECATION")
    fun load(ctx: Context): List<Song> {
        val out = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA
        )
        val selection =
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 15000"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            ctx.contentResolver.query(collection, projection, selection, null, sort)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val artist = c.getString(iArtist)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "अज्ञात कलाकार"
                    val album = c.getString(iAlbum)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "अज्ञात एल्बम"
                    val path = c.getString(iData) ?: ""
                    val folder = File(path).parentFile?.name?.takeIf { it.isNotBlank() } ?: "अन्य"
                    out.add(
                        Song(
                            id = id,
                            title = c.getString(iTitle) ?: "बिना नाम का गाना",
                            artist = artist,
                            album = album,
                            albumId = c.getLong(iAlbumId),
                            durationMs = c.getLong(iDur),
                            folder = folder,
                            uri = ContentUris.withAppendedId(collection, id)
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}

/** एल्बम का चित्र: सूची के लिए छोटा, प्लेयर के लिए बड़ा और साफ़ (HD). */
object ArtCache {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    suspend fun get(ctx: Context, s: Song, px: Int): Bitmap? = withContext(Dispatchers.IO) {
        val key = "${if (s.albumId > 0) s.albumId else -s.id}-$px"
        cache.get(key)?.let { return@withContext it }
        val bmp: Bitmap? = try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(s.uri, Size(px, px), null)
            } else {
                val art = ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"), s.albumId
                )
                ctx.contentResolver.openInputStream(art)?.use { BitmapFactory.decodeStream(it) }
            }
        } catch (_: Throwable) {
            null
        }
        if (bmp != null) cache.put(key, bmp)
        bmp
    }
}
