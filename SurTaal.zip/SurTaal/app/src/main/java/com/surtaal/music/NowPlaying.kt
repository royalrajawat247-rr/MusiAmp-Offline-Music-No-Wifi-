package com.surtaal.music

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Notes
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import kotlinx.coroutines.delay

@Composable
fun NowPlayingScreen(
    vm: PlayerViewModel,
    onClose: () -> Unit,
    onEq: () -> Unit,
    onTimer: () -> Unit,
    onTag: (Song) -> Unit
) {
    val song = vm.current
    val scheme = MaterialTheme.colorScheme
    var showLyrics by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }

    LaunchedEffect(song?.id, vm.isPlaying) {
        while (true) {
            if (!dragging) pos = vm.player.currentPosition
            delay(300)
        }
    }
    val dur = (song?.durationMs ?: 1L).coerceAtLeast(1L)
    val fav = song != null && vm.favorites.contains(song.id)

    Surface(Modifier.fillMaxSize(), color = scheme.background) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(scheme.primary.copy(alpha = 0.30f), scheme.background)))
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "छोटा करें", modifier = Modifier.size(32.dp))
                    }
                    Text(
                        "अभी चल रहा है",
                        Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelLarge,
                        color = scheme.onSurfaceVariant
                    )
                    IconButton(onClick = { song?.let(onTag) }) {
                        Icon(Icons.Rounded.Edit, "जानकारी बदलें")
                    }
                }

                // एल्बम का चित्र (या गीत के बोल)
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(28.dp))
                    ) {
                        if (showLyrics) {
                            val lyrics = song?.let { vm.tags[it.id]?.lyrics }.orEmpty()
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .background(scheme.surfaceVariant)
                                    .verticalScroll(rememberScrollState())
                                    .padding(20.dp),
                                contentAlignment = if (lyrics.isBlank()) Alignment.Center else Alignment.TopStart
                            ) {
                                Text(
                                    if (lyrics.isBlank()) "इस गाने के बोल अभी नहीं जुड़े हैं.\nऊपर ✏️ दबाकर खुद जोड़ें."
                                    else lyrics,
                                    style = MaterialTheme.typography.bodyLarge,
                                    textAlign = if (lyrics.isBlank()) TextAlign.Center else TextAlign.Start,
                                    color = scheme.onSurface
                                )
                            }
                        } else {
                            Art(song, Modifier.fillMaxSize(), px = 800, radius = 28.dp)
                        }
                    }
                }

                // नाम और पसंदीदा
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            song?.title ?: "कोई गाना नहीं चल रहा",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            song?.artist ?: "",
                            color = scheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = { song?.let { vm.toggleFavorite(it.id) } }) {
                        Icon(
                            if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            contentDescription = "पसंदीदा",
                            tint = if (fav) scheme.primary else scheme.onSurfaceVariant,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // समय की पट्टी
                Slider(
                    value = pos.coerceIn(0L, dur).toFloat(),
                    onValueChange = { dragging = true; pos = it.toLong() },
                    onValueChangeFinished = {
                        vm.player.seekTo(pos)
                        dragging = false
                    },
                    valueRange = 0f..dur.toFloat(),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(fmt(pos), style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
                    Text(fmt(dur), style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
                }

                Spacer(Modifier.height(8.dp))

                // चलाने के बटन
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { vm.toggleShuffle() }) {
                        Icon(
                            Icons.Rounded.Shuffle, "शफ़ल",
                            tint = if (vm.shuffle) scheme.primary else scheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { vm.previous() }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.SkipPrevious, "पिछला", modifier = Modifier.size(38.dp))
                    }
                    FilledIconButton(onClick = { vm.togglePlay() }, modifier = Modifier.size(72.dp)) {
                        Icon(
                            if (vm.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = "चलाएँ या रोकें",
                            modifier = Modifier.size(40.dp)
                        )
                    }
                    IconButton(onClick = { vm.next() }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.SkipNext, "अगला", modifier = Modifier.size(38.dp))
                    }
                    IconButton(onClick = { vm.cycleRepeat() }) {
                        Icon(
                            if (vm.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                            "दोहराएँ",
                            tint = if (vm.repeat == Player.REPEAT_MODE_OFF) scheme.onSurfaceVariant else scheme.primary
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                // नीचे की पट्टी: बोल, इक्वलाइज़र, टाइमर
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    IconButton(onClick = { showLyrics = !showLyrics }) {
                        Icon(
                            Icons.Rounded.Notes, "गीत के बोल",
                            tint = if (showLyrics) scheme.primary else scheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onEq) {
                        Icon(Icons.Rounded.Equalizer, "इक्वलाइज़र", tint = scheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onTimer) {
                        Icon(
                            Icons.Rounded.Bedtime, "सोने का टाइमर",
                            tint = if (vm.sleepEndsAt > 0) scheme.primary else scheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
