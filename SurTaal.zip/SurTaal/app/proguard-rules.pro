# SurTaal release rules (default Android rules are enough for this project)
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
